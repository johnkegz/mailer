"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppService = void 0;
const common_1 = require("@nestjs/common");
var AWS = require('aws-sdk');
let AppService = class AppService {
    sendMail() {
        var api_key = 'key-c527f1a56ed412b0064e09d9bd251849';
        var domain = 'sandbox54408a1cd3c547ab846cc7db1ea135b1.mailgun.org';
        var mailgun = require('mailgun-js')({ apiKey: api_key, domain: domain });
        var data = {
            from: 'John <johnkal24@gmail.com>',
            to: 'johnkal24@gmail.com',
            subject: 'Hello world now',
            text: 'Testing some Mailgun awesomeness!'
        };
        mailgun.messages().send(data, function (error, body) {
            if (error) {
                console.log("error +++>", error);
            }
            console.log("res +++>", body);
        });
        return 'Hello World!';
    }
    recieveWebHook(mailGunData) {
        if (mailGunData['event-data'].message.headers['message-id'].includes('mailgun.org')) {
            AWS.config.update({ region: 'us-east-2' });
            let data = {
                Provider: 'Mailgun',
                timestamp: mailGunData.signature.timestamp,
                type: "email " + mailGunData['event-data'].event
            };
            var params = {
                Message: JSON.stringify(data),
                TopicArn: 'arn:aws:sns:us-east-2:344027579703:mailgun'
            };
            var publishTextPromise = new AWS.SNS({ apiVersion: '2010-03-31' }).publish(params).promise();
            publishTextPromise.then(function (data) {
                console.log(`Message ${params.Message} sent to the topic ${params.TopicArn}`);
                console.log("MessageID is " + data.MessageId);
            }).catch(function (err) {
                console.error(err, err.stack);
            });
            return;
        }
        return;
    }
};
AppService = __decorate([
    common_1.Injectable()
], AppService);
exports.AppService = AppService;
//# sourceMappingURL=app.service.js.map