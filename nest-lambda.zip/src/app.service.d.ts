export declare class AppService {
    sendMail(): string;
    recieveWebHook(mailGunData: any): void;
}
